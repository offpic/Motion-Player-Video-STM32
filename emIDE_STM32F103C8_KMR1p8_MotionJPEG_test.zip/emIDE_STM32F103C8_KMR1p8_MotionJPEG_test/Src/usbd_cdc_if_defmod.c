/* Add header */

#include "VCP.h"

/* Define size for the receive and transmit buffer over CDC */
/* It's up to user to redefine and/or remove those define */

#define APP_RX_DATA_SIZE  256
#define APP_TX_DATA_SIZE  256

/**
  * @brief  CDC_Receive_FS
  *         Data received over USB OUT endpoint are sent over CDC interface 
  *         through this function.
  *           
  *         @note
  *         This function will block any OUT packet reception on USB endpoint 
  *         untill exiting this function. If you exit this function before transfer
  *         is complete on CDC interface (ie. using DMA controller) it will result 
  *         in receiving more data while previous ones are still not sent.
  *                 
  * @param  Buf: Buffer of data to be received
  * @param  Len: Number of data received (in bytes)
  * @retval Result of the operation: USBD_OK if all operations are OK else USBD_FAIL
  */

static int8_t CDC_Receive_FS (uint8_t* Buf, uint32_t *Len)
{
  /* USER CODE BEGIN 6 */

  if (hUsbDeviceFS.dev_state != USBD_STATE_CONFIGURED)
  {
    return USBD_FAIL;
  }

  if (((Buf == NULL) || (Len == NULL)) || (*Len <= 0))
  {
    return USBD_FAIL;
  }

  /* Get data */
  uint8_t result = USBD_OK;

  do
  {
     result = USBD_CDC_SetRxBuffer(&hUsbDeviceFS, &Buf[0]);
  }
  while(result != USBD_OK);

  do
  {
     result = USBD_CDC_ReceivePacket(&hUsbDeviceFS);
  }
  while(result != USBD_OK);

  /* Stops FIFO overflow*/
  if(RX_FIFO.FIFO_POS>=FIFO_SIZE)
  {
    return (USBD_OK);
  }

  /* Save date into FIFO */
  RX_FIFO.FIFO_DATA_LEN[RX_FIFO.FIFO_POS]=*Len;
  copy_array(RX_FIFO.FIFO_DATA[RX_FIFO.FIFO_POS],&Buf[0],*Len);

  RX_FIFO.FIFO_POS++; //move to next position to receive data

  return (USBD_OK);

  /* USER CODE END 6 */ 
}

/**
  * @brief  CDC_Transmit_FS
  *         Data send over USB IN endpoint are sent over CDC interface 
  *         through this function.           
  *         @note
  *         
  *                 
  * @param  Buf: Buffer of data to be send
  * @param  Len: Number of data to be send (in bytes)
  * @retval Result of the operation: USBD_OK if all operations are OK else USBD_FAIL or USBD_BUSY
  */

uint8_t CDC_Transmit_FS(uint8_t* Buf, uint16_t Len)
{
	if (hUsbDeviceFS.dev_state != USBD_STATE_CONFIGURED)
	{
		return USBD_FAIL;
	}

  uint8_t result = USBD_OK;

  /* USER CODE BEGIN 7 */ 

  USBD_CDC_HandleTypeDef *hcdc = (USBD_CDC_HandleTypeDef*)hUsbDeviceFS.pClassData;
  if (hcdc->TxState != 0){
    return USBD_BUSY;
  }

  USBD_CDC_SetTxBuffer(&hUsbDeviceFS, Buf, Len);
  result = USBD_CDC_TransmitPacket(&hUsbDeviceFS);

  /* USER CODE END 7 */ 
  return result;
}