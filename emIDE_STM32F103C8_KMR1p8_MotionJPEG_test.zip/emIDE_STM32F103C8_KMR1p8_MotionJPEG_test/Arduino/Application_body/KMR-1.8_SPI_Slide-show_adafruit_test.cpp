/*
 *    BMP/JPG/MJP file slide show program for KMR-1.8 SPI LCD
 *
 *    Original Libraris
 *      Adafruit_GFX    : URL  https://github.com/adafruit/Adafruit-GFX-Library
 *      Adafruit_ST7735 : URL  https://github.com/adafruit/Adafruit-ST7735-Library/
 *      JPEGDecoder : URL  https://github.com/MakotoKurauchi/JPEGDecoder
 *    Tools
 *      Picture resizing : Caesuyn Image Compressor
 *                         URL : https://saerasoft.com/caesium/
 *      Picture modification : "Paint" of Window's OS
 *      Motion Jpeg : Avidemux
 *                    URL : http://fixounet.free.fr/avidemux/
 *                          (Change generated file extention .raw to .mjp or .mjpeg)
 *
 */

/* device connections
  << KMR-1.8 SPI >>      << STM32F103C8:CPU board >>
     LED-                          G
     LED+                          3.3
     SC_CS                         PA4
     MOSI                          PB15
     MISO                          PB14
     SCK                           PB13
     CS                            PA3
     SCL                           PA5
     SDA                           PA7
     AO                            PA2
     RESET                         PA1
     VCC                           3.3
     GND                           G
*/

#include "Arduino_lib_wrapper.h"
#include "Adafruit_GFX.h"
#include "Adafruit_ST7735.h"
#include "SD.h"

// Define LCD port pin
#define SDCSPIN   PA4  // SD drive CS port number
#define TFT_CS    PA3  // LCD drive CS port number
#define TFT_RST   PA1  // LCD reset port number
#define TFT_DC    PA2  // LCD drive DC port number
//
#define OTHERTAB  0x03 // other tab
//
#define ROTNORM    1   // normal rotation
#define ROTRSID    2   // slide rotation
// Define using color
#define BLACK   0x0000
#define BLUE    0x001F
#define RED     0xF800
#define GREEN   0x07E0
#define CYAN    0x07FF
#define MAGENTA 0xF81F
#define YELLOW  0xFFE0
#define WHITE   0xFFFF

// bitmap/jpeg/motion-jpeg decoder
extern bool drawJpgBmppicture_adafruit_kmr(struct Adafruit_ST7735 *tft, char *fname);
extern bool drawJpgBmppicture_adafruit_kmr_mjpeg(struct Adafruit_ST7735 *tft, char *fname, uint8_t frate);

// Initialize display
static Adafruit_ST7735 myGLCD = Adafruit_ST7735(TFT_CS,  TFT_DC, TFT_RST);

// slid show drawing interval
#define DRAWINT   3000    // drawing interval (mS)

// initialize
void setup_slshow_adafruit()
{
  // open SPI port
  SPI.begin();

  // screen clear
#ifndef KMR1p8OLD  // for new brand KMR-1.8
  myGLCD.initR(INITR_BLACKTAB);
#else              // for old brand KMR-1.8
  myGLCD.initR(OTHERTAB);
#endif
  myGLCD.fillScreen(BLACK);

  // set rotation
  myGLCD.setRotation(ROTNORM);

  // set sd cs pin
  pinMode(SDCSPIN, OUTPUT);
  digitalWrite(SDCSPIN, HIGH);
}

// draw sd insert message
void MsgSdin_adafruit(unsigned short color, int kind){  // kind 0:insert SD, 1:insert checked
  #define FONTNUM  1  // font size number
  #define FONTWID  5  // font width
  #define FONTHIT  9  // font height
  myGLCD.setTextSize(FONTNUM);
  myGLCD.setTextColor(color);
  switch(kind){
    case 0:
      myGLCD.setCursor(myGLCD.width()/2 - FONTWID*7, myGLCD.height()/2 - (FONTHIT*3)/4);
      myGLCD.println("Please insert");
      myGLCD.setCursor(myGLCD.width()/2 - FONTWID*4, myGLCD.height()/2 + (FONTHIT*3)/4);
      myGLCD.println("SD card");
      break;
    case 1:
    case 2:
      myGLCD.setCursor(myGLCD.width()/2 - FONTWID*5 - FONTWID/2, myGLCD.height()/2 - FONTWID/2);
      if(kind == 1) myGLCD.println("SD inserted");
      else myGLCD.println("Reset board");
      break;
    default:
      break;
  }
  return;
}

// mail loop
void loop_slshow_adafruit()
{
  bool sdinflg = false;
  bool rstreq = false;
  unsigned long chktime = millis();
  File fp, root;
  unsigned char fname[18] = {0};

  // loop process
  while(1){
    // SD card inserted
    if(sdinflg){
       root = SD.open("/");
       delay(1);
       if(root) root.rewindDirectory();
       else {
         sdinflg = false;
         continue;
       }
       delay(1);
       rstreq = true;
       while(1){
         fp = root.openNextFile();
         if(!fp){
           if(!rstreq) break;
           else {
             sdinflg = false;
             goto rmvchk;
           }
         }
         rstreq = false;
         if (!fp.isDirectory()){
           // check BMP file
           unsigned char *ext = (unsigned char *)strrchr(fp.name(), '.');
           if(!ext || (memcmp(ext + 1, "BMP", 3) && memcmp(ext + 1, "JPG", 3) && memcmp(ext + 1, "MJP", 3))){
            nxtfl:
             fp.close();
             continue;
           }
           // set wait timer
           chktime = millis();
           // set file name
           memset(fname, 0, sizeof(fname));
           strcpy((char *)fname, fp.name());
           fp.close();
           // draw Jpeg & Bitmap picture
           if(!drawJpgBmppicture_adafruit_kmr_mjpeg(&myGLCD, (char *)fname, 5)) continue;
           chktime = millis() - 200;

           // check file exist
           fp = SD.open((char *)fname);
           unsigned char chkbuf[16];
           if(!fp.seek(0)) goto slend;
           // wait
           while(millis() < (chktime + DRAWINT)){
             delay(10);
             if(fp.read(chkbuf, 4) <= 0){
              slend:
               sdinflg = false;
               myGLCD.fillScreen(BLACK);
               goto rmvchk;
             }
           }
          fclse:
           fp.close();
        } else fp.close();
      }
      root.close();

    // SD card not inserted
    } else {
      // check SD card insert
      if(!rstreq){
        chktime = millis();
        SD.begin(SDCSPIN);
        if(millis() < (chktime + 50)){
          rstreq = false;
          sdinflg = true;
        } else {
          // set sd cs pin
          digitalWrite(SDCSPIN, HIGH);
          delay(100);
        }
      }

      // display message
    rmvchk:
      if(rstreq){
        MsgSdin_adafruit(RED, 2);
        delay(1000);
        MsgSdin_adafruit(BLACK, 2);
        delay(1000);
      } else if(!sdinflg){
        MsgSdin_adafruit(WHITE, 0);
        delay(500);
        MsgSdin_adafruit(BLACK, 0);
        delay(500);
        MsgSdin_adafruit(WHITE, 0);
      } else {
        MsgSdin_adafruit(BLACK, 0);
        MsgSdin_adafruit(GREEN, 1);
        delay(1000);
        MsgSdin_adafruit(BLACK, 1);
      }
    }
  }
}

