 /*
 *   Arduino library wrapper process
 *
 *     Arduiono_lib_wrapper.cpp
 *
 */
#include <string.h>
#include "stm32f1xx_hal.h"
#include "Arduino_lib_wrapper.h"
#include "VCP.h"

// spi, i2c, serial dummy
#ifdef SET_SPI2_DEFAULT         // SPI struct
 SPIdum SPI(2), SPI_2(1);
#else
 SPIdum SPI(1), SPI_2(2);
#endif
#ifdef SET_I2C2_DEFAULT         // Wire (I2C) struct
 Wiredum Wire(2), Wire_2(1);
#else
 Wiredum Wire(1), Wire_2(2);
#endif
#ifdef USEUSBCDC
  Serialcdc Serial_cdc;
#endif
#ifdef SET_SERIAL2_DEFAULT      // Uart struct
 Serialdum Serial(2), Serial_2(1);
#else
 Serialdum Serial(1), Serial_2(2);
#endif

// external reference
extern SPI_HandleTypeDef hspi[2];
extern I2C_HandleTypeDef hi2c[2];
extern UART_HandleTypeDef huart[2];

unsigned char settings = 0;

// delay millisecond
volatile unsigned long mselapse;
void delay(unsigned long wait){
  unsigned long starttime = mselapse;
  while(mselapse < (starttime + wait));
  return;
}

// report system clock (mS)
unsigned long millis(void){
  return mselapse;
}

// microseconds
unsigned long long micros(void){
  extern TIM_HandleTypeDef htim2;
  return (unsigned long long)(millis() * 1000) +
         (unsigned long long)__HAL_TIM_GET_COUNTER(&htim2);
}

// delay microsecond
void delayMicroseconds(unsigned long wait){
  unsigned long long starttime = micros();
  while(micros() < (starttime + (unsigned long long)wait));
}

// port table
const uint16_t pbit[] = {GPIO_PIN_0, GPIO_PIN_1, GPIO_PIN_2, GPIO_PIN_3, GPIO_PIN_4, GPIO_PIN_5,
                           GPIO_PIN_6, GPIO_PIN_7, GPIO_PIN_8, GPIO_PIN_9, GPIO_PIN_10,
                           GPIO_PIN_11, GPIO_PIN_12, GPIO_PIN_13, GPIO_PIN_14, GPIO_PIN_15};
const GPIO_TypeDef *port[] = {GPIOA, GPIOB, GPIOC};
// external reference
const uint16_t *ppbit = pbit;
const GPIO_TypeDef **pport = port;


// digital write
void digitalWrite(unsigned char pin, unsigned char value){
  // variables

  // check input
  if(((pin >> 4) == 0) || ((pin >> 4) > 3)) return;   // port select error

  // set port data
  HAL_GPIO_WritePin((GPIO_TypeDef *)port[(pin >> 4) - 1], pbit[pin & 0x0f], (value > 0) ? GPIO_PIN_SET : GPIO_PIN_RESET);

  // end of process
  return;
}

// digital pulse write
void digitalPulseWrite(unsigned char pin, unsigned char pol){
  // check input
  if(((pin >> 4) == 0) || ((pin >> 4) > 3)) return;   // port select error

  //
  if(pol == POSITIVE){
    ((GPIO_TypeDef *)port[(pin >> 4) - 1])->BSRR = pbit[pin & 0x0f];
    ((GPIO_TypeDef *)port[(pin >> 4) - 1])->BSRR = (uint32_t)pbit[pin & 0x0f] << 16U;
  } else {
    ((GPIO_TypeDef *)port[(pin >> 4) - 1])->BSRR = (uint32_t)pbit[pin & 0x0f] << 16U;
    ((GPIO_TypeDef *)port[(pin >> 4) - 1])->BSRR = pbit[pin & 0x0f];
  }

  // end of process
  return;
}

// digital input
unsigned char digitalRead(unsigned char pin){
  // read digital input
  return HAL_GPIO_ReadPin((GPIO_TypeDef *)port[(pin >> 4) - 1], pbit[pin & 0x0f]);
}

// pin mode
static int pinMode_comm(unsigned char pin, unsigned char mode, bool high){
  // variables
  GPIO_InitTypeDef GPIO_InitStruct;

  // check input
  if(((pin >> 4) == 0) || ((pin >> 4) > 3)) return -1;   // port select error

  // set output level to reset
  if(mode == OUTPUT) HAL_GPIO_WritePin((GPIO_TypeDef *)port[(pin >> 4) - 1], pbit[pin & 0x0f], GPIO_PIN_RESET);

  // set pin mode
  GPIO_InitStruct.Pin = pbit[pin & 0x0f];
  GPIO_InitStruct.Mode = (mode == OUTPUT) ? GPIO_MODE_OUTPUT_PP : GPIO_MODE_INPUT;
  if(mode == OUTPUT) GPIO_InitStruct.Speed = high ? GPIO_SPEED_FREQ_HIGH : GPIO_SPEED_FREQ_LOW;
  else GPIO_InitStruct.Pull = (mode == INPUT_PULLUP) ? GPIO_PULLUP : GPIO_NOPULL;
  HAL_GPIO_Init((GPIO_TypeDef *)port[(pin >> 4) - 1], &GPIO_InitStruct);
  return 0;
}

int pinMode(unsigned char pin, unsigned char mode){
  return pinMode_comm(pin, mode, false);
}

int pinMode_H(unsigned char pin, unsigned char mode){
  return pinMode_comm(pin, mode, true);
}

//
/* ADC1 init function */
ADC_HandleTypeDef hadc1;
void MX_ADC1_Init(void)
{
	/* Enable clock */
	__HAL_RCC_ADC1_CLK_ENABLE();

	/* Configure the ADC peripheral */
	hadc1.Instance = ADC1;

	/* Fill settings */
	hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
	hadc1.Init.ScanConvMode = DISABLE;
	hadc1.Init.ContinuousConvMode = DISABLE;
	hadc1.Init.DiscontinuousConvMode = DISABLE;
	hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
	hadc1.Init.NbrOfDiscConversion = 0;
	hadc1.Init.NbrOfConversion = 1;

	/* Init ADC */
	HAL_ADC_Init(&hadc1);
}

// analog read
unsigned long analogRead(unsigned char pin){         // pin is PA0 - PA7, PB0, PB1 (A0 - A9)
  /* variables */
  ADC_ChannelConfTypeDef sConfig;

  /* check port number */
  if(((pin < PA0) || (pin > PA7)) && (pin != PB0) && (pin != PB1)) return 0;

  /* ADC port enable */
   __HAL_RCC_ADC1_CLK_ENABLE();
  GPIO_InitTypeDef GPIO_InitStruct;
  GPIO_InitStruct.Pin = pbit[pin & 0x0f];
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init((GPIO_TypeDef *)port[(pin >> 4) - 1], &GPIO_InitStruct);
  /* Init ADC */
  MX_ADC1_Init();

  /* Configure ADC regular channel */
  uint8_t pno = ((pin >= PA0) && (pin <= PA7)) ? pin & 0x0f : (pin & 0x0f) + 8;
  sConfig.Channel = pno;
  sConfig.Rank = 1;

  /* Return zero */
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK) {
    return 0;
  }

  /* Start conversion */
  if (HAL_ADC_Start(&hadc1) != HAL_OK) {
    return 0;
  }

  /* Poll for end */
  HAL_ADC_PollForConversion(&hadc1, 10);

  /* Check if the continous conversion of regular channel is finished */
  if (HAL_ADC_GetState(&hadc1) != HAL_OK) {
    /* Get the converted value of regular channel */
    return ((HAL_ADC_GetValue(&hadc1) + 2) >> 2);
  }

  /* stop conversion */
  HAL_ADC_Stop(&hadc1);

  /* ADC disable */
  __HAL_RCC_ADC1_CLK_DISABLE();
   HAL_GPIO_DeInit((GPIO_TypeDef *)port[(pin >> 4) - 1], pbit[pin & 0x0f]);

  /* Return zero */
  return 0;
}

// analog PWM output
int analogWrite(unsigned char pin, unsigned int val){    // pin is CH1 to CH3, input 0 - 255
  // variables
  extern TIM_HandleTypeDef htim2;
  unsigned char pinp[4] = {PA15, PB3, PB10, PB11};
  unsigned long pwmch[4] = {TIM_CHANNEL_1, TIM_CHANNEL_2, TIM_CHANNEL_3, TIM_CHANNEL_4};
  int pwmchp;

  // check pin number
  for(pwmchp = 0 ; pwmchp < 4 ; pwmchp++){
    if(pin == pinp[pwmchp]) break;
    else if(pwmchp >= 3) return -1;
  }

  // set port
  GPIO_InitTypeDef GPIO_InitStruct;
  GPIO_InitStruct.Pin = pbit[pin & 0x0f];
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init((GPIO_TypeDef *)port[(pin >> 4) - 1], &GPIO_InitStruct);

    __HAL_AFIO_REMAP_TIM2_ENABLE();

  // set pwm mode
  TIM_OC_InitTypeDef sConfig;
  sConfig.OCMode = TIM_OCMODE_PWM1;
  sConfig.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfig.OCFastMode = TIM_OCFAST_DISABLE;
  sConfig.Pulse = (unsigned long)val * 4;
  HAL_TIM_PWM_ConfigChannel(&htim2, &sConfig, pwmch[pwmchp]);

  // pwm output start
  HAL_TIM_PWM_Start(&htim2, pwmch[pwmchp]);

  //
  return 0;
}

// SPI dummy functions
void SPIdum::setDataMode(unsigned char mode){
  if(!bgn) begin();
  hspi[pno - 1].Init.CLKPolarity = ((mode == SPI_MODE0) || (mode == SPI_MODE1)) ? SPI_POLARITY_LOW : SPI_POLARITY_HIGH;
  hspi[pno - 1].Init.CLKPhase = ((mode == SPI_MODE0) || (mode == SPI_MODE2)) ? SPI_PHASE_1EDGE : SPI_PHASE_2EDGE;
  HAL_SPI_Init(&hspi[pno - 1]);
}

const uint32_t brtbl[8] = {SPI_BAUDRATEPRESCALER_2, SPI_BAUDRATEPRESCALER_4, SPI_BAUDRATEPRESCALER_8, SPI_BAUDRATEPRESCALER_16,
                           SPI_BAUDRATEPRESCALER_32, SPI_BAUDRATEPRESCALER_64, SPI_BAUDRATEPRESCALER_128, SPI_BAUDRATEPRESCALER_256};

void SPIdum::setClockDivider(unsigned char div){
  if(!bgn) begin();
  hspi[pno - 1].Init.BaudRatePrescaler = brtbl[div];
  HAL_SPI_Init(&hspi[pno - 1]);
}

void SPIdum::setBitOrder(unsigned char order){
  if(!bgn) begin();
  hspi[pno - 1].Init.FirstBit = (order == MSBFIRST) ? SPI_FIRSTBIT_MSB : SPI_FIRSTBIT_LSB;
  HAL_SPI_Init(&hspi[pno - 1]);
}

uint8_t SPIdum::transfer(unsigned char data){
  uint8_t rxd;
  if(!bgn) begin();
  __HAL_SPI_ENABLE(&hspi[pno - 1]);
  HAL_SPI_TransmitReceive(&hspi[pno - 1], &data, &rxd, 1, 1000);
  __HAL_SPI_DISABLE(&hspi[pno - 1]);
  return rxd;
}

void SPIdum::rxblockdata(uint8_t *block, uint16_t len){
  memset(block, 0xFF, len);
  HAL_SPI_Receive(&hspi[pno - 1], block, len, 1000);
}

void SPIdum::rxblockdata_dma(uint8_t *block, uint16_t len){
  memset(block, 0xFF, len);
  waitReady();
  HAL_SPI_Receive_DMA(&hspi[pno - 1], block, len);
}

void SPIdum::beginTransaction(unsigned char setting){
  if(!bgn) begin();
  hspi[pno - 1].Init.BaudRatePrescaler = brtbl[(setting >> 3) & 7];
  hspi[pno - 1].Init.FirstBit = ((setting & 1) == MSBFIRST) ? SPI_FIRSTBIT_MSB : SPI_FIRSTBIT_LSB;
  unsigned char mode = (setting >> 1) & 3;
  hspi[pno - 1].Init.CLKPolarity = ((mode == SPI_MODE0) || (mode == SPI_MODE1)) ? SPI_POLARITY_LOW : SPI_POLARITY_HIGH;
  hspi[pno - 1].Init.CLKPhase = ((mode == SPI_MODE0) || (mode == SPI_MODE2)) ? SPI_PHASE_1EDGE : SPI_PHASE_2EDGE;
  HAL_SPI_Init(&hspi[pno - 1]);
}

// settings = b5-b3/clock, b2-b1:mode, b0:order
unsigned char SPISettings(uint32_t clock, unsigned char order, unsigned char mode){
  unsigned char clk = 0;
  if(clock >= 18000000) clk = 0;
  else if(clock >= 9000000) clk = 1;
  else if(clock >= 4500000) clk = 2;
  else if(clock >= 2250000) clk = 3;
  else if(clock >= 1125000) clk = 4;
  else if(clock >= 562500) clk = 5;
  else if(clock >= 281250) clk = 6;
  else clk = 7;
  return (((clk & 7) << 3) | ((mode & 3) << 1) | (order & 1));
}

// I2C dummy functions
#define TIMEOUT  100    // time out period
#define I2C_TIMEOUT_FLAG          35U         /*!< Timeout 35 ms             */
#define I2C_TIMEOUT_BUSY_FLAG     25U         /*!< Timeout 25 ms             */
#define I2C_NO_OPTION_FRAME       0xFFFF0000U /*!< XferOptions default value */
#define I2C_STATE_MSK             ((uint32_t)((HAL_I2C_STATE_BUSY_TX | HAL_I2C_STATE_BUSY_RX) & (~(uint32_t)HAL_I2C_STATE_READY))) /*!< Mask State define, keep only RX and TX bits            */
#define I2C_STATE_NONE            ((uint32_t)(HAL_I2C_MODE_NONE))                                                        /*!< Default Value                                          */
#define I2C_STATE_MASTER_BUSY_TX  ((uint32_t)((HAL_I2C_STATE_BUSY_TX & I2C_STATE_MSK) | HAL_I2C_MODE_MASTER))            /*!< Master Busy TX, combinaison of State LSB and Mode enum */
#define I2C_STATE_MASTER_BUSY_RX  ((uint32_t)((HAL_I2C_STATE_BUSY_RX & I2C_STATE_MSK) | HAL_I2C_MODE_MASTER))            /*!< Master Busy RX, combinaison of State LSB and Mode enum */
#define I2C_STATE_SLAVE_BUSY_TX   ((uint32_t)((HAL_I2C_STATE_BUSY_TX & I2C_STATE_MSK) | HAL_I2C_MODE_SLAVE))             /*!< Slave Busy TX, combinaison of State LSB and Mode enum  */
#define I2C_STATE_SLAVE_BUSY_RX   ((uint32_t)((HAL_I2C_STATE_BUSY_RX & I2C_STATE_MSK) | HAL_I2C_MODE_SLAVE))             /*!< Slave Busy RX, combinaison of State LSB and Mode enum  */
//
extern "C" {
  HAL_StatusTypeDef I2C_WaitOnFlagUntilTimeout(I2C_HandleTypeDef *hi2c, uint32_t Flag, FlagStatus Status, uint32_t Timeout, uint32_t Tickstart);
  HAL_StatusTypeDef I2C_MasterRequestWrite(I2C_HandleTypeDef *hi2c, uint16_t DevAddress, uint32_t Timeout, uint32_t Tickstart);
  HAL_StatusTypeDef I2C_WaitOnTXEFlagUntilTimeout(I2C_HandleTypeDef *hi2c, uint32_t Timeout, uint32_t Tickstart);
  HAL_StatusTypeDef I2C_WaitOnBTFFlagUntilTimeout(I2C_HandleTypeDef *hi2c, uint32_t Timeout, uint32_t Tickstart);
}

void Wiredum::begin(unsigned char spd){
  hi2c[pno - 1].Init.ClockSpeed = (unsigned long)spd * 100000;
  HAL_I2C_Init(&hi2c[pno - 1]);
  return;
}


bool Wiredum::beginTransmission(unsigned char addr){
  //
  uint32_t tickstart = HAL_GetTick();
  if(hi2c[pno - 1].State != HAL_I2C_STATE_READY){
    txerr = true;
    return true;
  }

  /* Wait until BUSY flag is reset */
  if(I2C_WaitOnFlagUntilTimeout(&hi2c[pno - 1], I2C_FLAG_BUSY, SET, I2C_TIMEOUT_BUSY_FLAG, tickstart) != HAL_OK){
    txerr = true;
    return true;
  }

  /* Check if the I2C is already enabled */
  if((hi2c[pno - 1].Instance->CR1 & I2C_CR1_PE) != I2C_CR1_PE) __HAL_I2C_ENABLE(&hi2c[pno - 1]);

  /* Disable Pos */
  hi2c[pno - 1].Instance->CR1 &= ~I2C_CR1_POS;
  hi2c[pno - 1].State     = HAL_I2C_STATE_BUSY_TX;
  hi2c[pno - 1].Mode      = HAL_I2C_MODE_MASTER;
  hi2c[pno - 1].ErrorCode = HAL_I2C_ERROR_NONE;

  /* Prepare transfer parameters */
  hi2c[pno - 1].XferOptions = I2C_NO_OPTION_FRAME;

  /* Send Slave Address */
  if(I2C_MasterRequestWrite(&hi2c[pno - 1], addr << 1, TIMEOUT, tickstart) != HAL_OK){
    txerr = true;
    return true;
  }

  /* Clear ADDR flag */
  __HAL_I2C_CLEAR_ADDRFLAG(&hi2c[pno - 1]);

  txerr = false;
  return false;
}

bool Wiredum::write(unsigned char data){
  //
  if(txerr) return true;

  /* Wait until TXE flag is set */
  uint32_t tickstart = HAL_GetTick();
  if(I2C_WaitOnTXEFlagUntilTimeout(&hi2c[pno - 1], TIMEOUT, tickstart) != HAL_OK){
    if(hi2c[pno - 1].ErrorCode == HAL_I2C_ERROR_AF) hi2c[pno - 1].Instance->CR1 |= I2C_CR1_STOP;
    txerr = true;
    return true;
  }

  /* Write data to DR */
  hi2c[pno - 1].Instance->DR = data;

  /* Wait until BTF flag is set */
  if(I2C_WaitOnBTFFlagUntilTimeout(&hi2c[pno - 1], TIMEOUT, tickstart) != HAL_OK){
    if(hi2c[pno - 1].ErrorCode == HAL_I2C_ERROR_AF) hi2c[pno - 1].Instance->CR1 |= I2C_CR1_STOP;
    txerr = true;
    return true;
  }

  return false;
}

unsigned char Wiredum::endTransmission(bool stp){
  //
  if(txerr) return 4;

  /* Generate Stop */
  if(stp) hi2c[pno - 1].Instance->CR1 |= I2C_CR1_STOP;

  hi2c[pno - 1].State = HAL_I2C_STATE_READY;
  hi2c[pno - 1].Mode = HAL_I2C_MODE_NONE;

  return 0;
}

unsigned char Wiredum::requestFrom(unsigned char addr, unsigned char len){
  // get read data buffers
  if(rxbuf) free(rxbuf);        // release former memory
  delay(1);
  rxbuf = (unsigned char *)malloc(len);  // get new memory

  // read data
  rxdp = 0; rxlen = 0;
  if(HAL_I2C_Master_Receive(&hi2c[pno - 1], addr << 1, rxbuf, len, 1000) != HAL_OK){
    rxlen = len - hi2c[pno - 1].XferSize;
  } else rxlen = len;

  return rxlen;
}

unsigned char Wiredum::read(void){
  unsigned char rxd = 0;
  if(rxbuf){
    if(rxdp < rxlen) rxd = rxbuf[rxdp++];
    else if(rxdp >= rxlen){
      free(rxbuf);
      rxbuf = 0;
    }
  }
  return rxd;
}

// UART dummy functions
extern "C" void USART1_IRQHandler_wrap(void);
void USART1_IRQHandler_wrap(void){
  if(__HAL_UART_GET_FLAG(&huart[0], UART_FLAG_RXNE) != RESET)
#if SET_SERIAL2_DEFAULT
    Serial_2.UartRxHandler();
#else
    Serial.UartRxHandler();
#endif
}

extern "C" void USART2_IRQHandler_wrap(void);
void USART2_IRQHandler_wrap(void){
  if(__HAL_UART_GET_FLAG(&huart[1], UART_FLAG_RXNE) != RESET)
#if SET_SERIAL2_DEFAULT
    Serial.UartRxHandler();
#else
    Serial_2.UartRxHandler();
#endif
}

void Serialdum::begin(unsigned long spd){
  huart[pno - 1].Init.BaudRate = spd;
  HAL_UART_Init(&huart[pno - 1]);
  __HAL_UART_ENABLE_IT(&huart[pno - 1], UART_IT_RXNE);
  rxbuf = (unsigned char *)malloc(UARTRXBUFFLEN);
  rxbwpt = 0;
}

void Serialdum::end(void){
  HAL_NVIC_DisableIRQ((pno > 0) ? USART2_IRQn : USART1_IRQn);
  HAL_UART_DeInit(&huart[pno - 1]);
  free(rxbuf);
}

int Serialdum::read(void){
  int rtn = -1;
  if(rxbwpt > 0){
    __disable_irq();
    rtn = rxbuf[0];
    for(int i = 1 ; i < rxbwpt ; i++) rxbuf[i - 1] = rxbuf[i];
    rxbwpt--;
    rxbuf[rxbwpt] = 0;
    __enable_irq();
  }
  return rtn;
}

int Serialdum::peek(void){
  int rtn = -1;
  if(rxbwpt > 0) rtn = rxbuf[0];
  return rtn;
}

size_t Serialdum::write(unsigned char val){
  HAL_UART_Transmit(&huart[pno - 1], &val, 1, 1000);
  return 1;
}

size_t Serialdum::write(unsigned char *str, unsigned char len){
  size_t txb = 0;
  for(int i = 0 ; i < len ; i++) txb += write(*(str+i));
  return txb;
}

void Serialdum::UartRxHandler(void){
  uint8_t data;
  HAL_UART_Receive(&huart[pno - 1], &data, 1, 1000);
  if(rxbwpt < UARTRXBUFFLEN) rxbuf[rxbwpt++] = data;
}

#ifdef USEUSBCDC
void Serialcdc::begin(unsigned long spd){
  rxbuf = 0;
  for(int i = 0 ; i < 300 ; i++){
    if(VCP_chkcnect()){
      rxbuf = (unsigned char *)malloc(UARTRXBUFFLEN);
      delay(100);
      break;
    }
    delay(10);
  }
  rxbwpt = 0;
}

void Serialcdc::end(void){
  free(rxbuf);
}

int Serialcdc::read(void){
  int rtn = -1;
  unsigned char lrxbuf[256];
  unsigned long lrxlen;
  if(VCP_read(lrxbuf, &lrxlen) != 0){
    for(int i = 0 ; (i < lrxlen) && (rxbwpt < UARTRXBUFFLEN) ; i++) rxbuf[rxbwpt++] = lrxbuf[i];
  }
  if(rxbwpt > 0){
    rtn = rxbuf[0];
    for(int i = 1 ; i < rxbwpt ; i++) rxbuf[i - 1] = rxbuf[i];
    rxbwpt--;
    rxbuf[rxbwpt] = 0;
  }
  return rtn;
}

int Serialcdc::peek(void){
  int rtn = -1;
  unsigned char lrxbuf[256];
  unsigned long lrxlen;
  if(VCP_read(lrxbuf, &lrxlen) != 0){
    for(int i = 0 ; (i < lrxlen) && (rxbwpt < UARTRXBUFFLEN) ; i++) rxbuf[rxbwpt++] = lrxbuf[i];
  }
  if(rxbwpt > 0) rtn = rxbuf[0];
  return rtn;
}

size_t Serialcdc::write(unsigned char val){
  VCP_write(&val, 1);
  return 1;
}

size_t Serialcdc::write(unsigned char *str, unsigned char len){
  size_t txb = 0;
  for(int i = 0 ; i < len ; i++) txb += write(*(str+i));
  return txb;
}
#endif

