//
//  This program generate sine cosine value
//
//  FILE: sinefunc.cpp
//

// sine table (1 degree to 90 degree, value 0 - 200)
const unsigned Sinetbl[] =
{ //1    2    3    4    5    6    7    8   9    10
    3,   7,  10,  14,  17,  20,  24,  28,  31,  35,  //   1 to  10 degree
   38,  42,  45,  48,  52,  55,  58,  62,  65,  68,  //  11 to  20 degree
   72,  75,  78,  81,  85,  88,  90,  94,  97, 100,  //  21 to  30 degree
  103, 106, 109, 112, 115, 118, 120, 123, 126, 129,  //  31 to  40 degree
  131, 134, 136, 139, 141, 144, 146, 149, 151, 153,  //  41 to  50 degree
  155, 158, 160, 162, 164, 166, 168, 170, 171, 173,  //  51 to  60 degree
  175, 177, 178, 180, 181, 183, 184, 185, 187, 188,  //  61 to  70 degree
  189, 190, 191, 192, 193, 194, 195, 196, 196, 197,  //  71 to  80 degree
  198, 198, 199, 199, 199, 200, 200, 200, 200, 200,  //  81 to  90 degree
};

// get sine value
float Sin_l(float angle){
  // check input angle
  bool vneg = (angle < 0) ? true : false;
  int absangle = ((int)((vneg ? -angle : angle) + 0.5)) % 360;
  bool aneg = (absangle > 180) ? true : false;

  // get terget angle value
  int hfangle = absangle % 180;
  if(!hfangle) return 0;  // check 0 degree
  float oval = (hfangle > 90) ? (float)Sinetbl[180 - hfangle - 1] / 200 : (float)Sinetbl[hfangle - 1] / 200;

  // set signe of value
  if((!vneg && aneg) || (vneg && !aneg)) oval = -oval;

  // return value
  return oval;
}

// get cosine value
float Cos_l(float angle){
  return Sin_l(angle + 90);
}
