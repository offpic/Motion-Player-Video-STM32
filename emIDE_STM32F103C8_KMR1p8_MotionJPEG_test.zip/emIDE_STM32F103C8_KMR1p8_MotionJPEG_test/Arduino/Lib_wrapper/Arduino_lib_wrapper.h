/*
 *   Arduino library wrapper process header
 *
 *     Arduino_lib_wrapper.h
 *
 */

#ifndef __ARDUINO_LIB_WAPPER_H
#define __ARDUINO_LIB_WAPPER_H

// include file
#include <stdint.h>
#include <stdio.h>
#include "stm32f1xx_hal.h"
#include "Configuration.h"
#include "Print.h"

// Device selection definition (Old type using comment out next line)
#define STM32F103C8     // for STM32F103C8
#ifdef KMR1p8OLD
 #define RGBSETV   0    // old type LCD
#else
 #define RGBSETV   8    // new type LCD
#endif

// SD card SPI default port selection
#ifndef SDCARD_SPI
 #define SDCARD_SPI SPI_2
#endif

// definition
#define HIGH  1
#define LOW   0

// pin mode
#define INPUT         0
#define INPUT_PULLUP  1
#define OUTPUT        2

// pulse polarity
#define POSITIVE      1
#define NEGATIVE      0

// SPI param
#define SPI_MODE0         0
#define SPI_MODE1         1
#define SPI_MODE2         2
#define SPI_MODE3         3
#define SPI_CLOCK_DIV2    0
#define SPI_CLOCK_DIV4    1
#define SPI_CLOCK_DIV8    2
#define SPI_CLOCK_DIV16   3
#define SPI_CLOCK_DIV32   4
#define SPI_CLOCK_DIV64   5
#define SPI_CLOCK_DIV128  6
#define SPI_CLOCK_DIV256  7
#define MSBFIRST          0
#define LSBFIRST          1

/*  --- bit port assign ---  */
// port A
#define PA0   0x10
#define PA1   0x11
#define PA2   0x12
#define PA3   0x13
#define PA4   0x14
#define PA5   0x15
#define PA6   0x16
#define PA7   0x17
#define PA8   0x18
#define PA9   0x19
#define PA10  0x1A
#define PA11  0x1B
#define PA12  0x1C
#define PA13  0x1D
#define PA14  0x1E
#define PA15  0x1F
// port B
#define PB0   0x20
#define PB1   0x21
#define PB2   0x22
#define PB3   0x23
#define PB4   0x24
#define PB5   0x25
#define PB6   0x26
#define PB7   0x27
#define PB8   0x28
#define PB9   0x29
#define PB10  0x2A
#define PB11  0x2B
#define PB12  0x2C
#define PB13  0x2D
#define PB14  0x2E
#define PB15  0x2F
// port C
#define PC0   0x30
#define PC1   0x31
#define PC2   0x32
#define PC3   0x33
#define PC4   0x34
#define PC5   0x35
#define PC6   0x36
#define PC7   0x37
#define PC8   0x38
#define PC9   0x39
#define PC10  0x3A
#define PC11  0x3B
#define PC12  0x3C
#define PC13  0x3D
#define PC14  0x3E
#define PC15  0x3F
//
// SPI port
#define MOSI  PA7
#define MISO  PA6
#define SCK   PA5
#define SS    PA4
// SPI_2 port
#define MOSI  PB15
#define MISO  PB14
#define SCK   PB13
#define SS    PB12
// Analog input port
#define ADCIN0  PA0
#define ADCIN1  PA1
#define ADCIN2  PA2
#define ADCIN3  PA3
#define ADCIN4  PA4
#define ADCIN5  PA5
#define ADCIN6  PA6
#define ADCIN7  PA7
#define ADCIN8  PB0
#define ADCIN9  PB1

// PWM output port (TIM2 out)
#define PWMOUT1 PA15  // PA15 port
#define PWMOUT2 PB3   // PB3 port
#define PWMOUT3 PB10  // PB10 port
#define PWMOUT4 PB11  // PB11 port

// UART
#define UART_RX  PA10  // PA10 port
#define UART_TX  PA9   // PA9 port
// UART_2
#define UART_RX  PA3   // PA3 port
#define UART_TX  PA2   // PA2 port

//
#define BIN        2  // binary value
#define OCT        8  // octibal value
#define DEC       10  // decimal value
#define HEX       16  // hexadecimal value

// I2C
#define I2C_SCL  PB4  // PB4 port
#define I2C_SDA  PB5  // PB5 port
#define I2C_HIGH 4    // 400KHz mode
#define I2C_MID  2    // 200KHz mode
#define I2C_STD  1    // 100KHz mode

// SPI param definition
#define MOSI   PC6    // PC6 port
#define MISO   PC7    // PC7 port
#define SCK    PC5    // PC5 port
#define SS     PA3    // PA3 port
#define SPI_MODE0    0
#define SPI_MODE1    1
#define SPI_MODE2    2
#define SPI_MODE3    3

// other definition
#define PI 3.141592
//************************************************

/*  --- external reference ---*/
// timer
extern void delay(unsigned long wait);
extern unsigned long millis(void);
extern unsigned long long micros(void);
extern void delayMicroseconds(unsigned long wait);
// SPI
extern void SendSPIData(unsigned char *buffer, int length);
extern void GetSPIData(unsigned char *buffer, int length);
extern void SendWRxSPIData(unsigned char *txd, unsigned char *rxd, int length);
// GPIO
extern void digitalWrite(unsigned char pin, unsigned char value);
extern void digitalPulseWrite(unsigned char pin, unsigned char pol);
extern unsigned char digitalRead(unsigned char pin);
extern int pinMode(unsigned char pin, unsigned char mode);
extern int pinMode_H(unsigned char pin, unsigned char mode);
// analog I/O
extern unsigned long analogRead(unsigned char pin);         // pin is AIN2 to AIN6, return 0 - 1023
extern int analogWrite(unsigned char pin, unsigned int val);     // pin is CH1 to CH3, input 0 - 255
// arduino main process
extern void setup(void);
extern void loop(void);
// sine/cosine function
extern float Sin_l(float angle);
extern float Cos_l(float angle);

// dummy
extern unsigned char settings;
extern unsigned char SPISettings(uint32_t clock, unsigned char order, unsigned char mode);

#ifdef  __cplusplus
// dummy class
extern SPI_HandleTypeDef hspi[2];
extern int volatile dmatxstart;
class SPIdum {
  public:
    SPIdum(char port){ pno = port; bgn = false;}     // set port number 1 or 2
    void begin(void){ HAL_SPI_Init(&hspi[pno - 1]); bgn = true;/* ldmatime = 0;*/
                      /*__HAL_RCC_DMA1_CLK_ENABLE();*/ }
    void end(void){ HAL_SPI_MspDeInit(&hspi[pno - 1]); bgn = false;}
    void setDataMode(unsigned char mode);
    void setClockDivider(unsigned char div);
    void setBitOrder(unsigned char order);
    void beginTransaction(unsigned char setting);
    void endTransaction(void){ ;}
    uint8_t transfer(unsigned char data);
    void txblockdata(unsigned char *block, uint16_t len){ HAL_SPI_Transmit(&hspi[pno - 1], block, len, 1000);}
    void txblockdata_dma(unsigned char *block, uint16_t len){
      waitReady();
      HAL_SPI_Transmit_DMA(&hspi[pno - 1], block, len);
    }
    void waitReady(void){ while(hspi[pno - 1].State != HAL_SPI_STATE_READY);}
    void rxblockdata(uint8_t *block, uint16_t len);
    void rxblockdata_dma(uint8_t *block, uint16_t len);
  private:
    char pno;
    bool bgn;
//    unsigned long long ldmatime;
};
extern SPIdum  SPI, SPI_2;

// dummy I2C class (master only)
class Wiredum{
  public:
    Wiredum(char port){ rxbuf = 0; pno = port;}
    void begin(unsigned char spd);  // spd:I2C_HIGH, I2C_MID, I2C_STD
    void begin(void){ begin(I2C_STD);}
    bool beginTransmission(unsigned char addr);
    bool write(unsigned char data);
    unsigned char endTransmission(bool stp);
    unsigned char endTransmission(void){ return endTransmission(true);}
    unsigned char requestFrom(unsigned char addr, unsigned char len);
    unsigned char available(void){ return rxlen;}
    unsigned char read(void);
  private:
    unsigned char rxdp;            // rx data point
    unsigned char rxlen;           // rx data length
    unsigned char *rxbuf;          // rx data buffer point
    char pno;                      // port number
    bool txerr;                    // tx error flag
};
extern Wiredum Wire, Wire_2;

// dummy UART class
#define UARTRXBUFFLEN   256        // uart rx buffer length
class Serialdum : public Print{
  private:
    unsigned char *rxbuf;
    unsigned char rxbwpt;
    char pno;                      // port number

  public:
    Serialdum(char port){ pno = port;}
    using Print::write;
    void begin(unsigned long spd=9600);
    void end(void);
    unsigned char available(void){ return rxbwpt;}  // tx, rx buffer 16 bytes
    int read(void);
    int peek(void);
    void flush(void){ ;}
    size_t write(unsigned char val);
    size_t write(unsigned char *str, unsigned char len);
    size_t write(const char *str, unsigned char len){ return write((unsigned char *)str, len);}
    size_t write(const char *str){ return write(str, strlen(str));}
    void UartRxHandler(void);
};

#ifdef USEUSBCDC
// CDC UART class
class Serialcdc : public Print{
    private:
    unsigned char *rxbuf;
    unsigned char rxbwpt;

  public:
    using Print::write;
    void begin(unsigned long spd=9600);
    void end(void);
    unsigned char available(void){ return rxbwpt;}  // tx, rx buffer 16 bytes
    int read(void);
    int peek(void);
    void flush(void){ ;}
    size_t write(unsigned char val);
    size_t write(unsigned char *str, unsigned char len);
    size_t write(const char *str, unsigned char len){ return write((unsigned char *)str, len);}
    size_t write(const char *str){ return write(str, strlen(str));}
};

extern Serialcdc Serial_cdc;
#endif
extern Serialdum Serial, Serial_2;

//
typedef bool boolean;
#else
 #define Serial_cdc Serial
#endif

// convert function that not supported in this standard C
extern char *ltoa (long __val, char *__s, int __radix);
extern char *dtostrf (double val, signed char width, unsigned char prec, char *sout);
extern char *ultoa (unsigned long __val, char *__s, int __radix);

#endif /* __ARDUINO_LIB_WAPPER_H */
