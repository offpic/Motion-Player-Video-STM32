/*
  Arduino dummy header
     Arduino.h
*/

#ifndef ARDUINO_H
#define ARDUINO_H

#include "Arduino_lib_wrapper.h"

#define byte unsigned char

#endif
