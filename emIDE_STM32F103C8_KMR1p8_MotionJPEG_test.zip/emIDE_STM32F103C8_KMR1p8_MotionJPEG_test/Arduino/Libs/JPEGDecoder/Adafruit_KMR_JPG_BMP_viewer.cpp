/*
 *    Jpeg/Motion-Jpeg & Bitmap file picuter viewer program for KMR-1.8 SPI LCD
 *
 */

#include <stdio.h>
#include "Arduino_lib_wrapper.h"
#include "Adafruit_GFX.h"
#include "Adafruit_ST7735.h"
#include "SD.h"
#include "JPEGDecoder.h"

#define BLACK   0x0000
#define DEFFRATE     5  // default frame rate

// Jpeg/Motion-Jpeg & Bitmap still picture drawing (true:OK, false:Error)
bool drawJpgBmppicture_adafruit_kmr_mjpeg(struct Adafruit_ST7735 *tft, char *fname, uint8_t frate){
  // variables
  bool rlt = false;
  File fp;
  unsigned long nxtdt;

  // check BMP/JPEG file
  char *ext = strrchr(fname, '.');
  if(!ext || (memcmp(ext + 1, "BMP", 3) && memcmp(ext + 1, "JPG", 3) && memcmp(ext + 1, "MJP", 3))) return false;
  // check jpeg file
  if(!memcmp(ext + 1, "JPG", 3) || !memcmp(ext + 1, "MJP", 3)){
    // check & set mottion jpeg
    if(!memcmp(ext + 1, "MJP", 3)) JpegDec.mjpegflag = 1;
    else JpegDec.mjpegflag = 0;
    // variables
    uint8 *pImg;
    int x, y, bx, by;
    uint16_t col = BLACK;
    bool inifrmset = true;
    // draw picture
    do{
      // set next picture draw timing
      if(JpegDec.mjpegflag) nxtdt = millis() + 1000 / ((frate > 0) ? frate : DEFFRATE);
      // check decording parameter
      if((JpegDec.decode(fname, 0) < 0) || !JpegDec.height || !JpegDec.width) return false;
      // set draw offset parameters
      long xofset = (tft->width() - JpegDec.width) / 2;
      long yofset = (tft->height() - JpegDec.height) / 2;
      if(inifrmset){
        // set top black belt
        if(yofset > 0) tft->fillRect(0, 0, tft->width(), yofset, BLACK);
        // set left & right black belt
        if(xofset > 0){
          tft->fillRect(0, (yofset > 0) ? yofset : 0, xofset, (yofset > 0) ? JpegDec.height : tft->height(), BLACK);
          tft->fillRect(xofset + JpegDec.width, (yofset > 0) ? yofset : 0, tft->width() - JpegDec.width - xofset, (yofset > 0) ? JpegDec.height : tft->height(), BLACK);
        }
        inifrmset = false;
      }
      // start jpeg decode
      while(JpegDec.read()){
        // check draw range and get draw parameters
        pImg = JpegDec.pImage ;
        long dxstrt = JpegDec.MCUx * JpegDec.MCUWidth + xofset; if(dxstrt >= tft->width()) continue;
        if(dxstrt < 0) dxstrt = 0;
        long dystrt = JpegDec.MCUy * JpegDec.MCUHeight + yofset; if(dystrt >= tft->height()) continue;
        if(dystrt < 0) dystrt = 0;
        long dxend = (JpegDec.MCUx + 1) * JpegDec.MCUWidth - 1 + xofset; if(dxend < 0) continue;
        if(dxend >= tft->width()) dxend = tft->width() - 1;
        long dyend = (JpegDec.MCUy + 1) * JpegDec.MCUHeight - 1 + yofset; if(dyend < 0) continue;
        if(dyend >= tft->height()) dyend = tft->height() - 1;
        // draw princture
        bool drawstart = true;
        uint16_t clbuf[JpegDec.MCUWidth * JpegDec.MCUHeight]; uint16_t clbufpt = 0;
        for(by = 0 ; by < JpegDec.MCUHeight ; by++){
          // draw decoded image
          y = JpegDec.MCUy * JpegDec.MCUHeight + by;
          // check image end
          if(y >= JpegDec.height) break;
          if(((y + yofset) < 0) || ((y + yofset) >= tft->height())) continue;
          // draw image
          for(bx = 0 ; bx < JpegDec.MCUWidth ; bx++){
            x = JpegDec.MCUx * JpegDec.MCUWidth + bx;
            // check image draw range
            if(((x + xofset) < 0) || ((x + xofset) >= tft->width())) continue;
            // start drawing
            if(drawstart){
              // set draw window
              tft->setAddrWindow(dxstrt, dystrt, dxend, dyend);
              // clear draw start flag
              drawstart = false;
            }
            // get & set pixel data
            if(JpegDec.comps == 1) // Grayscale
              col = (((unsigned short)pImg[0] >> 3) << 11) | (((unsigned short)pImg[0] >> 2) << 5) | (pImg[0] >> 3);
            else // RGB
              col = (((unsigned short)pImg[0] >> 3) << 11) | (((unsigned short)pImg[1] >> 2) << 5) | (pImg[2] >> 3);
            // check picture draw range & set color
            if(x >= JpegDec.width) col = BLACK;
            if(((xofset + x) >= 0) && ((yofset + y) >= 0) && ((xofset + x) < tft->width()) && ((yofset + y) < tft->height()))
              clbuf[clbufpt++] = col;
            pImg += JpegDec.comps;
          }
        }
        // draw picture
        if(clbufpt) tft->pushColors(clbuf, clbufpt);
      }
      // set bottom black belt
      if(yofset > 0) tft->fillRect(0, yofset + JpegDec.height, tft->width(), tft->height(), BLACK);
      // check next picture wait timing
      if(JpegDec.mjpegflag){
        long picdly = nxtdt - millis();
        if(picdly > 0) delay(picdly);
      }
      //
    } while(JpegDec.mjpegflag && JpegDec.nextjpgpos);
    // end of drawing
    rlt = true;

  // check bitmap file
  } else {
    // check file header
    #define RDPLEN   256   // read packets length
    unsigned char rdbuf[RDPLEN * 3];
    fp = SD.open(fname);
    fp.read(rdbuf, 34);
    if((rdbuf[0] != 'B') || (rdbuf[1] != 'M')) goto rtnend;  // check ID
    if(rdbuf[30] || rdbuf[31] || rdbuf[32] || rdbuf[33]) goto rtnend;  // check no compressin
    if((rdbuf[28] | ((unsigned short)rdbuf[29] << 8)) != 24) goto rtnend;  // check 24bits mode
    // get file parameters
    unsigned long lwidth = rdbuf[18] | ((unsigned long)rdbuf[19] << 8) |
                           ((unsigned long)rdbuf[20] << 16) | ((unsigned long)rdbuf[21] << 24);
    unsigned long lheight = rdbuf[22] | ((unsigned long)rdbuf[23] << 8) |
                           ((unsigned long)rdbuf[24] << 16) | ((unsigned long)rdbuf[25] << 24);
    unsigned long offset = rdbuf[10] | ((unsigned long)rdbuf[11] << 8) |
                           ((unsigned long)rdbuf[12] << 16) | ((unsigned long)rdbuf[13] << 24);
    int drwidth = (lwidth <= tft->width()) ? lwidth : tft->width();
    int drhight = (lheight <= tft->height()) ? lheight : tft->height();
    int drxofset = (tft->width() - lwidth) / 2;
    int dryofset = (tft->height() - lheight) / 2;
    unsigned long lpwidth = (lwidth * 3) + ((((lwidth * 3) % 4) > 0) ? 4 - ((lwidth * 3) % 4) : 0);
    // set draw area parameter
    tft->setAddrWindow(0, 0, tft->width()-1, tft->height()-1);

    // draw screen
    uint16_t blkblt[tft->width()]; memset(blkblt, 0, sizeof(blkblt));
    for(int y = 0 ; y < tft->height() ; y++){
      // draw blank line
      if((tft->height() > lheight) && ((y < dryofset) || (y >= (dryofset + drhight)))){
        tft->pushColors((uint16_t *)blkblt, tft->width());
        continue;
      }
      // draw y line picture
      for(int ly = 0 ; ly < drhight ; ly++){
        // draw x line
        for(int x = 0 ; x < tft->width() ; x++){
          // draw left & right blank
          if((tft->width() > lwidth) && ((x < drxofset) || (x >= (drxofset + drwidth)))){
            tft->pushColor(BLACK);
            continue;
          }
          // draw x line picture
          unsigned long rowidx = (lheight - ly - 1 + ((dryofset < 0) ? dryofset : 0)) * lpwidth +
                                                 ((drxofset < 0) ? -drxofset * 3 : 0);
          fp.seek(rowidx + offset);
          for(int lx = 0 ; lx < drwidth ; lx += RDPLEN){
            int rdpklen = ((lx + RDPLEN) < drwidth) ? RDPLEN : drwidth - lx;
            if(fp.read(rdbuf, rdpklen * 3) <= 0) goto rtnend;
            uint16_t clbuf[rdpklen];
            for(int ln = 0 ; ln < rdpklen ; ln++)
              clbuf[ln] = (((unsigned short)rdbuf[ln * 3 + 2] >> 3) << 11) |
                           (((unsigned short)rdbuf[ln * 3 + 1] >> 2) << 5) | (rdbuf[ln * 3] >> 3);
            tft->pushColors(clbuf, rdpklen);
          }
          x += (drwidth - 1);
        }
      }
      y += (drhight - 1);
    }
    rlt = true;
  }

  // process end
 rtnend:
  if(!memcmp(ext + 1, "BMP", 3)) fp.close();
  return rlt;
}

// Jpeg & Bitmap still picture drawing (true:OK, false:Error)
bool drawJpgBmppicture_adafruit_kmr(struct Adafruit_ST7735 *tft, char *fname){
  return drawJpgBmppicture_adafruit_kmr_mjpeg(tft, fname, 0);
}
