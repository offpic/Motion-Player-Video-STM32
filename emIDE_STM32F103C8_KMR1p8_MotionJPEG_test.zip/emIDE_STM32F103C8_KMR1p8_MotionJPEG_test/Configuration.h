/*
 *   Program configuration header
 *
 *     Configuration.h
 *
 */

#ifndef __CONFIGURATION_H
#define __CONFIGURATION_H

// external reference
extern void setup_slshow_adafruit(void);
extern void loop_slshow_adafruit(void);
//
#define Setup setup_slshow_adafruit
#define Loop loop_slshow_adafruit
#define SDCARD_SPI SPI_2
#define USELCDTXDMA        // use dma for SPI tx
#define USESDDMA           // use dma for SD card SPI

#endif /* __CONFIGURATION_H */
